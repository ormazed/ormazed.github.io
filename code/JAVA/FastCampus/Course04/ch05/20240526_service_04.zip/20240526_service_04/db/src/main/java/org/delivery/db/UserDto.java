package org.delivery.db;

public class UserDto {
}
